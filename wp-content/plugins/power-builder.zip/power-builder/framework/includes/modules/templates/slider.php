<?php
/**
 * Template part for Slider module displaying
 */
?>
<div class="tm_pb_slides">
	<?php echo $this->shortcode_content; ?>
</div> <!-- .tm_pb_slides -->
